This package lets user to simulate data from a liner model controlling some important parameters. Only tuning few parameters, user can simulate data with wide range of properties.

