# `pysimrel`: Simulation of Linear Model Data

[![Documentation Status](https://readthedocs.org/projects/pysimrel/badge/?version=latest)](http://pysimrel.readthedocs.io/?badge=latest)
[![Build Status](https://travis-ci.org/simulatr/pysimrel.svg?branch=master)](https://travis-ci.org/simulatr/pysimrel)
[![codecov](https://codecov.io/gh/simulatr/pysimrel/branch/master/graph/badge.svg)](https://codecov.io/gh/simulatr/pysimrel)


This package lets user to simulate data from a liner model controlling some important parameters. Only tuning few parameters, user can simulate data with wide range of properties.

